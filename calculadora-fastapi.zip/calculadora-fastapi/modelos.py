from pydantic import BaseModel

class EntradaOperacao(BaseModel):
    a: float
    b: float
