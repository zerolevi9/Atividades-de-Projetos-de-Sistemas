# CalcFastAPI_lib

Biblioteca FastAPI para cálculos rápidos.

## Instalação

```bash
pip install calcfastapi-lib
```

## Uso

```python
from fastapi import FastAPI
from calcfastapi_lib.main import app

# ... use app with Uvicorn
```
