from fastapi import FastAPI
from .api.calc_router import router

app = FastAPI(title="CalcFastAPI")

app.include_router(router)
