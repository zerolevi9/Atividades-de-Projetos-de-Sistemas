from fastapi import APIRouter
from calcfastapi_lib.services.calc_service import soma, subtrai

router = APIRouter(prefix="/calc", tags=["calc"])

@router.get("/soma")
def get_soma(a: float, b: float):
    return {"resultado": soma(a, b)}

@router.get("/subtracao")
def get_subtrai(a: float, b: float):
    return {"resultado": subtrai(a, b)}
