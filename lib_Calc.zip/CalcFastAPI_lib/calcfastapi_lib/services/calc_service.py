def soma(a: float, b: float) -> float:
    return a + b

def subtrai(a: float, b: float) -> float:
    return a - b
