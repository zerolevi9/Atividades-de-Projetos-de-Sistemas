# CalcFastapi_lib
Calculadora com fastapi
