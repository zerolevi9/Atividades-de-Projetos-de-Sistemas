from fastapi import FastAPI
from calcfastapi_lib.api.router import router

app = FastAPI(title="CalcFastAPI")
app.include_router(router)
