from fastapi import APIRouter
from calcfastapi_lib.services.calculator import add, subtract

router = APIRouter(prefix="/calc", tags=["calc"])

@router.get("/add")
def get_add(a: float, b: float):
    return {"result": add(a, b)}

@router.get("/subtract")
def get_subtract(a: float, b: float):
    return {"result": subtract(a, b)}
