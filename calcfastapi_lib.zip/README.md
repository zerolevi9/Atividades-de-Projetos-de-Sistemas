# CalcFastAPI_lib

Python library for quick calculations powered by FastAPI.

## Installation

```bash
pip install calcfastapi-lib
```

## Usage

```python
from fastapi import FastAPI
from calcfastapi_lib.main import app
```
