interface Operacao {
    double calcular(double a, double b);
}