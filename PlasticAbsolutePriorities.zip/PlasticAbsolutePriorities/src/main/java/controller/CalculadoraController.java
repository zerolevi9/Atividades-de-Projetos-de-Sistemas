class CalculadoraController {
    private CalculadoraView view;

    public CalculadoraController(CalculadoraView view) {
        this.view = view;
    }

    public void executarOperacao(Operacao operacao, double a, double b) {
        double resultado = operacao.calcular(a, b);
        view.mostrarResultado(resultado);
    }
}