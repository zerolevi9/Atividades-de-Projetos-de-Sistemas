class CalculadoraView {
    public void mostrarResultado(double resultado) {
        System.out.println("Resultado: " + resultado);
    }
}
