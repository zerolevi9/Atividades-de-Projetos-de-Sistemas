public class CalculadoraMVC {
    public static void main(String[] args) {
        CalculadoraView view = new CalculadoraView();
        CalculadoraController controller = new CalculadoraController(view);

        // Testando operações
        controller.executarOperacao(new Soma(), 10, 5);
        controller.executarOperacao(new Subtracao(), 10, 5);
        controller.executarOperacao(new Multiplicacao(), 10, 5);
        controller.executarOperacao(new Divisao(), 10, 5);
    }
}